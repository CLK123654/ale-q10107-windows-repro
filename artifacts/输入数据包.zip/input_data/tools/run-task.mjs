import fs from "node:fs";
import path from "node:path";
import process from "node:process";
import { DatabaseSync } from "node:sqlite";
import { fileURLToPath } from "node:url";

const toolsDir = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(toolsDir, "..");
const sourceDbPath = path.join(root, "database", "api_metering.db");
const contractPath = path.join(root, "rules", "billing_contract.json");
const reportContractPath = path.join(root, "rules", "report_contract.json");
const outputRoot = path.join(root, "output");
const outputDbPath = path.join(outputRoot, "api_billing_repaired.db");
const sqlPath = path.join(outputRoot, "rebuild_api_billing.sql");
const reportRoot = path.join(outputRoot, "reports");

function cleanupDynamic() {
  fs.rmSync(outputDbPath, { force: true });
  fs.rmSync(reportRoot, { recursive: true, force: true });
}

function fail(message, code = 1) {
  cleanupDynamic();
  process.stderr.write(`${message}\n`);
  process.exit(code);
}

function rows(db, sql) {
  return db.prepare(sql).all().map((row) => Object.fromEntries(Object.entries(row)));
}

function stableRows(db, table, orderBy) {
  return JSON.stringify(rows(db, `SELECT * FROM ${table} ORDER BY ${orderBy}`));
}

function csvCell(value) {
  const text = value == null ? "" : String(value);
  return /[",\r\n]/.test(text) ? `"${text.replaceAll('"', '""')}"` : text;
}

function writeCsv(filePath, columns, dataRows) {
  const lines = [
    columns.join(","),
    ...dataRows.map((row) => columns.map((column) => csvCell(row[column])).join(",")),
  ];
  fs.writeFileSync(filePath, `${lines.join("\n")}\n`, "utf8");
}

cleanupDynamic();
for (const requiredPath of [sourceDbPath, contractPath, reportContractPath, sqlPath]) {
  if (!fs.existsSync(requiredPath)) fail(`缺少必需输入或完成版：${path.relative(root, requiredPath)}`, 2);
}

let db;
try {
  const contract = JSON.parse(fs.readFileSync(contractPath, "utf8"));
  const reportContract = JSON.parse(fs.readFileSync(reportContractPath, "utf8"));
  const excludedStatuses = contract.excluded_tenant_status;
  if (!Array.isArray(excludedStatuses) || excludedStatuses.length === 0) {
    fail("billing_contract.json缺少excluded_tenant_status", 2);
  }
  if (!Array.isArray(reportContract.reports) || reportContract.reports.length === 0) {
    fail("report_contract.json缺少reports", 2);
  }
  fs.mkdirSync(outputRoot, { recursive: true });
  fs.copyFileSync(sourceDbPath, outputDbPath);
  db = new DatabaseSync(outputDbPath);
  db.exec("PRAGMA foreign_keys=ON");

  const sourceTables = {
    tenant_account: stableRows(db, "tenant_account", "tenant_id"),
    plan_family_quota: stableRows(db, "plan_family_quota", "tenant_id, api_family"),
    price_tier: stableRows(db, "price_tier", "api_family, tier_start_units"),
    usage_event: stableRows(db, "usage_event", "event_id"),
    credit_adjustment: stableRows(db, "credit_adjustment", "adjustment_id"),
  };

  db.exec(`
    CREATE TEMP TABLE runtime_contract (
      billing_period_start_utc TEXT NOT NULL,
      billing_period_end_utc TEXT NOT NULL,
      included_usage_status TEXT NOT NULL
    );
    CREATE TEMP TABLE runtime_excluded_tenant_status (
      status TEXT PRIMARY KEY
    );
  `);
  db.prepare("INSERT INTO runtime_contract VALUES (?, ?, ?)").run(
    contract.billing_period_start_utc,
    contract.billing_period_end_utc,
    contract.included_usage_status,
  );
  const statusInsert = db.prepare("INSERT INTO runtime_excluded_tenant_status VALUES (?)");
  for (const status of excludedStatuses) statusInsert.run(status);

  db.exec(fs.readFileSync(sqlPath, "utf8"));

  const sourcePreserved = Object.entries(sourceTables).every(([table, snapshot]) => {
    const orderBy = {
      tenant_account: "tenant_id",
      plan_family_quota: "tenant_id, api_family",
      price_tier: "api_family, tier_start_units",
      usage_event: "event_id",
      credit_adjustment: "adjustment_id",
    }[table];
    return stableRows(db, table, orderBy) === snapshot;
  });
  const integrityOk = db.prepare("PRAGMA integrity_check").get().integrity_check === "ok";
  const foreignKeyOk = rows(db, "PRAGMA foreign_key_check").length === 0;
  const tables = rows(db, "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name").map((row) => row.name);
  const expectedTables = [
    "adjustment_in_scope",
    "billing_meta",
    "credit_adjustment",
    "eligible_usage",
    "exclusion_review",
    "family_usage",
    "plan_family_quota",
    "price_tier",
    "tenant_account",
    "tenant_invoice",
    "usage_event",
  ];
  const tableSetExact = JSON.stringify(tables) === JSON.stringify(expectedTables);

  if (!integrityOk || !foreignKeyOk || !sourcePreserved || !tableSetExact) {
    fail("修复库完整性、外键、源表保护或表集合不符合交付要求", 5);
  }
  fs.mkdirSync(reportRoot, { recursive: true });
  const safeIdentifier = /^[a-z_][a-z0-9_]*$/u;
  for (const report of reportContract.reports) {
    if (!safeIdentifier.test(report.table) || !Array.isArray(report.columns)
        || !report.columns.every((column) => safeIdentifier.test(column))
        || !/^[a-z0-9_, ]+$/u.test(report.order_by)
        || !/^[a-z0-9_]+\.csv$/u.test(report.file)) {
      fail("report_contract.json含非法表名、字段、排序或文件名", 2);
    }
    const data = rows(db, `SELECT ${report.columns.join(", ")} FROM ${report.table} ORDER BY ${report.order_by}`);
    writeCsv(path.join(reportRoot, report.file), report.columns, data);
  }
  const invoices = rows(db, "SELECT * FROM tenant_invoice ORDER BY tenant_id");
  const finalDue = invoices.reduce((sum, row) => sum + row.final_due_cents, 0);
  db.close();
  db = null;

  const outputPaths = [
    "api_billing_repaired.db",
    "rebuild_api_billing.sql",
    "reports/exclusion_review.csv",
    "reports/family_usage.csv",
    "reports/tenant_invoice.csv",
  ];
  const actualPaths = [];
  const collect = (directory, prefix = "") => {
    for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
      const relative = prefix ? `${prefix}/${entry.name}` : entry.name;
      if (entry.isDirectory()) collect(path.join(directory, entry.name), relative);
      else actualPaths.push(relative);
    }
  };
  collect(outputRoot);
  actualPaths.sort();
  if (JSON.stringify(actualPaths) !== JSON.stringify(outputPaths)) {
    fail(`交付成员不符：${actualPaths.join(",")}`, 4);
  }
  process.stdout.write(`API计费复核通过：租户${invoices.length}个，最终应收${finalDue}美分\n`);
} catch (error) {
  try {
    db?.close();
  } catch {
  }
  fail(error?.stack ?? String(error), 3);
}
