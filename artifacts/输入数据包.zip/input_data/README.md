这批材料用于核对API平台2026年7月账单。database/api_metering.db保存租户、免费额度、价格阶梯、用量事件和账单调整，租户及账务字段已经脱敏。

rules/billing_contract.json给出账期、纳入状态、重试去重、免费额度、credit和月度封顶规则。rules/report_contract.json规定财务账单、API族用量和排除复核三张报表的字段及排序，运行入口会读取两份规则。

在output/rebuild_api_billing.sql提交完成版SQL，然后于input_data目录运行npm run process。入口使用Node.js24内置SQLite复制源库，载入合同参数，执行SQL并按报表合同导出结果。成功后output包含修复库、完成版SQL和三张CSV；发生错误时不改写源库。
