PRAGMA foreign_keys=ON;

DROP TABLE IF EXISTS eligible_usage;
DROP TABLE IF EXISTS family_usage;
DROP TABLE IF EXISTS adjustment_in_scope;
DROP TABLE IF EXISTS tenant_invoice;
DROP TABLE IF EXISTS exclusion_review;
DROP TABLE IF EXISTS billing_meta;

CREATE TABLE eligible_usage AS
WITH contract AS (
  SELECT * FROM runtime_contract
),
classified AS (
  SELECT
    u.*,
    CASE
      WHEN u.event_time_utc < c.billing_period_start_utc
        OR u.event_time_utc >= c.billing_period_end_utc
        THEN 'outside_billing_period'
      WHEN u.event_status <> c.included_usage_status
        THEN 'status_not_committed'
      WHEN u.billable_flag <> 1
        THEN 'preview_not_billable'
      WHEN EXISTS (
        SELECT 1
        FROM runtime_excluded_tenant_status x
        WHERE x.status = t.billing_status
      )
        THEN 'tenant_not_billable'
      ELSE NULL
    END AS exclusion_reason
  FROM usage_event u
  JOIN tenant_account t ON t.tenant_id = u.tenant_id
  CROSS JOIN contract c
),
ranked AS (
  SELECT
    classified.*,
    ROW_NUMBER() OVER (
      PARTITION BY request_key
      ORDER BY ingested_at_utc, event_id
    ) AS duplicate_rank
  FROM classified
  WHERE exclusion_reason IS NULL
)
SELECT
  event_id,
  request_key,
  tenant_id,
  api_family,
  units,
  event_time_utc,
  ingested_at_utc
FROM ranked
WHERE duplicate_rank = 1;

CREATE TABLE family_usage AS
WITH rollup AS (
  SELECT tenant_id, api_family, SUM(units) AS gross_units
  FROM eligible_usage
  GROUP BY tenant_id, api_family
),
billable AS (
  SELECT
    r.tenant_id,
    r.api_family,
    r.gross_units,
    COALESCE(q.free_units, 0) AS free_units,
    MAX(r.gross_units - COALESCE(q.free_units, 0), 0) AS billable_units
  FROM rollup r
  LEFT JOIN plan_family_quota q
    ON q.tenant_id = r.tenant_id
   AND q.api_family = r.api_family
)
SELECT
  b.tenant_id,
  b.api_family,
  b.gross_units,
  b.free_units,
  b.billable_units,
  SUM(
    CASE
      WHEN b.billable_units < p.tier_start_units THEN 0
      ELSE (
        MIN(
          b.billable_units,
          COALESCE(p.tier_end_units, b.billable_units)
        ) - p.tier_start_units + 1
      ) * p.unit_price_cents
    END
  ) AS charge_cents
FROM billable b
JOIN price_tier p ON p.api_family = b.api_family
GROUP BY b.tenant_id, b.api_family, b.gross_units, b.free_units, b.billable_units;

CREATE TABLE adjustment_in_scope AS
SELECT
  a.adjustment_id,
  a.tenant_id,
  a.amount_cents,
  a.reason_code,
  a.approved_at_utc
FROM credit_adjustment a
CROSS JOIN runtime_contract c
WHERE a.adjustment_status = 'approved'
  AND a.approved_at_utc >= c.billing_period_start_utc
  AND a.approved_at_utc < c.billing_period_end_utc;

CREATE TABLE tenant_invoice AS
WITH subtotal AS (
  SELECT tenant_id, SUM(charge_cents) AS usage_charge_cents
  FROM family_usage
  GROUP BY tenant_id
),
credit AS (
  SELECT tenant_id, SUM(amount_cents) AS approved_credit_cents
  FROM adjustment_in_scope
  GROUP BY tenant_id
),
pre_cap AS (
  SELECT
    s.tenant_id,
    t.plan_name,
    t.currency,
    t.monthly_cap_cents,
    s.usage_charge_cents,
    COALESCE(c.approved_credit_cents, 0) AS approved_credit_cents,
    s.usage_charge_cents + COALESCE(c.approved_credit_cents, 0) AS pre_cap_due_cents
  FROM subtotal s
  JOIN tenant_account t ON t.tenant_id = s.tenant_id
  LEFT JOIN credit c ON c.tenant_id = s.tenant_id
)
SELECT
  tenant_id,
  plan_name,
  currency,
  monthly_cap_cents,
  usage_charge_cents,
  approved_credit_cents,
  pre_cap_due_cents,
  MAX(pre_cap_due_cents - monthly_cap_cents, 0) AS cap_reduction_cents,
  MIN(pre_cap_due_cents, monthly_cap_cents) AS final_due_cents
FROM pre_cap
ORDER BY tenant_id;

CREATE TABLE exclusion_review AS
WITH contract AS (
  SELECT * FROM runtime_contract
),
classified AS (
  SELECT
    u.*,
    CASE
      WHEN u.event_time_utc < c.billing_period_start_utc
        OR u.event_time_utc >= c.billing_period_end_utc
        THEN 'outside_billing_period'
      WHEN u.event_status <> c.included_usage_status
        THEN 'status_not_committed'
      WHEN u.billable_flag <> 1
        THEN 'preview_not_billable'
      WHEN EXISTS (
        SELECT 1
        FROM runtime_excluded_tenant_status x
        WHERE x.status = t.billing_status
      )
        THEN 'tenant_not_billable'
      ELSE NULL
    END AS exclusion_reason
  FROM usage_event u
  JOIN tenant_account t ON t.tenant_id = u.tenant_id
  CROSS JOIN contract c
),
ranked_valid AS (
  SELECT
    classified.*,
    ROW_NUMBER() OVER (
      PARTITION BY request_key
      ORDER BY ingested_at_utc, event_id
    ) AS duplicate_rank
  FROM classified
  WHERE exclusion_reason IS NULL
),
usage_exclusion AS (
  SELECT
    event_id AS source_id,
    'usage_event' AS source_table,
    tenant_id,
    api_family,
    exclusion_reason,
    units AS affected_units,
    event_time_utc AS observed_at_utc
  FROM classified
  WHERE exclusion_reason IS NOT NULL
  UNION ALL
  SELECT
    event_id,
    'usage_event',
    tenant_id,
    api_family,
    'duplicate_request_key',
    units,
    event_time_utc
  FROM ranked_valid
  WHERE duplicate_rank > 1
),
adjustment_exclusion AS (
  SELECT
    a.adjustment_id AS source_id,
    'credit_adjustment' AS source_table,
    a.tenant_id,
    '' AS api_family,
    CASE
      WHEN a.adjustment_status <> 'approved' THEN 'adjustment_not_approved'
      ELSE 'outside_billing_period'
    END AS exclusion_reason,
    a.amount_cents AS affected_units,
    a.approved_at_utc AS observed_at_utc
  FROM credit_adjustment a
  CROSS JOIN runtime_contract c
  WHERE a.adjustment_status <> 'approved'
     OR a.approved_at_utc < c.billing_period_start_utc
     OR a.approved_at_utc >= c.billing_period_end_utc
)
SELECT * FROM usage_exclusion
UNION ALL
SELECT * FROM adjustment_exclusion;

CREATE TABLE billing_meta (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);
INSERT INTO billing_meta
SELECT 'billing_period_start', billing_period_start_utc FROM runtime_contract
UNION ALL
SELECT 'billing_period_end', billing_period_end_utc FROM runtime_contract
UNION ALL
SELECT 'source_usage_row_count', CAST(COUNT(*) AS TEXT) FROM usage_event
UNION ALL
SELECT 'eligible_usage_row_count', CAST(COUNT(*) AS TEXT) FROM eligible_usage
UNION ALL
SELECT 'family_usage_rows', CAST(COUNT(*) AS TEXT) FROM family_usage
UNION ALL
SELECT 'invoice_rows', CAST(COUNT(*) AS TEXT) FROM tenant_invoice
UNION ALL
SELECT 'exclusion_rows', CAST(COUNT(*) AS TEXT) FROM exclusion_review
UNION ALL
SELECT 'final_due_cents', CAST(SUM(final_due_cents) AS TEXT) FROM tenant_invoice;
